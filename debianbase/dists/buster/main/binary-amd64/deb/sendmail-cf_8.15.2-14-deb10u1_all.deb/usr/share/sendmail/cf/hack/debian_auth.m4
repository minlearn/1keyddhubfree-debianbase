divert(-1)dnl
#-----------------------------------------------------------------------------
# $Sendmail: debian_auth.m4,v 8.15.2 2019-08-25 15:04:16 cowboy Exp $
#
# Copyright (c) 2001-2010 Richard Nelson.  All Rights Reserved.
#
# cf/hack/debian_auth.m4.  Generated from debian_auth.m4.in by configure.
#
# debian_trustauth.m4 m4 file for
#	* supporting MSP->MTA and MTA->MTA authentication
#	* supporting the auth= parameter on the mail from: command.
#
# This file is an extremely simple example that lets *ALL* trusted users
# sendmail, daemon, root, uucp, etc. proxy for any user.
#
# If you've a better idea, please let me know
#
#-----------------------------------------------------------------------------
divert(0)dnl
VERSIONID(`$Id: debian_auth.m4,v 8.15.2-14~deb10u1 2019-08-25 15:04:16 cowboy Exp $')
dnl #
dnl # MTA as Client authentication - only if authinfo/access_db *NOT* used...
define(`confDEF_AUTH_INFO', `MAIL_SETTINGS_DIR`'default-auth-info')dnl
dnl #
dnl # add (fake) uid 'sendmail' to trusted users - it is used as the id
dnl # for MSP->MTA, and MTA->MTA proxying.
ifdef(`confTRUSTED_USERS',
	`define(`confTRUSTED_USERS',
		defn(`confTRUSTED_USERS')`,sendmail')',
	`define(`confTRUSTED_USERS', `sendmail')')dnl
dnl #
dnl # Define local rulesets for trust_auth
LOCAL_RULESETS
#
#-----------------------------------------------------------------------------
# Local_trust_auth: Define who is able to authenticate for whom...
# The sendmail default is to allow *IFF* authen == author
# This ruleset also allows trusted users to authenicate as anyone - needed
# for MSP->MTA and MTA->MTA forwarding of mail from: <...> auth=...
SLocal_trust_auth
R$*	$: $&{auth_authen}	    Put authentication id in the workspace
ifdef(`DEBIAN_DEBUG',dnl
`R$*	$: $(log authtype:$&{auth_type} $) $1
R$*	$: $(log authauthen:$&{auth_authen} $) $1
R$*	$: $(log authauthor:$&{auth_author} $) $1')
R$=t	$@ $#ok Trusted users...    Allow trusted users to auth= as anyone
#-----------------------------------------------------------------------------
