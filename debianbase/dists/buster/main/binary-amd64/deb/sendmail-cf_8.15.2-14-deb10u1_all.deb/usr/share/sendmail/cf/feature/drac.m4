define(`_DRAC_', `')

LOCAL_CONFIG
Kdrac ifelse(defn(`_ARG_'), `', DATABASE_MAP_TYPE MAIL_SETTINGS_DIR`drac',
		`_ARG_')
