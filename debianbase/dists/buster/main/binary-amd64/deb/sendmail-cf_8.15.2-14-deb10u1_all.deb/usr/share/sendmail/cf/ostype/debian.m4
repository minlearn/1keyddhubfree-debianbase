divert(-1)dnl
#-----------------------------------------------------------------------------
# $Sendmail: debian.m4,v 8.15.2 2019-08-25 15:04:16 cowboy Exp $
#
# Copyright (c) 1998-2010 Richard Nelson.  All Rights Reserved.
#
# cf/ostype/debian.m4.  Generated from debian.m4.in by configure.
#
# ostype(debian) config file for building Sendmail 8.15.2-14~deb10u1
#
# Note: the .in file supports 8.7.6 - 9.0.0, but the generated
#	file is customized to the version noted above.
#
#-----------------------------------------------------------------------------
#
divert(0)dnl
dnl #
dnl #---------------------------------------------------------------------
dnl # Bring in Autoconf results
dnl #---------------------------------------------------------------------
ifdef(`sm_version', `dnl',
`include(`/usr/share/sendmail/cf/debian/autoconf.m4')dnl')
dnl #
VERSIONID(`$Id: debian.m4, v 8.15.2-14~deb10u1 2019-08-25 15:04:16 cowboy Exp $')
define(`confCF_VERSION', `Debian-14~deb10u1')dnl
dnl #
dnl # changes made herein *must* be reflected in parse_mc,update_db,debian.m4
dnl #
ifdef(`MAIL_SETTINGS_DIR', `dnl',
	`define(`MAIL_SETTINGS_DIR', `/etc/mail/')dnl')
dnl # support 8.9.3 migration to 8.10.0 naming convention
dnl # Note: this is too late... needs to be in sendmail.mc - at top
ifdef(`_USE_ETC_MAIL_', `dnl', `define(`_USE_ETC_MAIL_')dnl')
dnl #
dnl # Define default greeting
define(`confSMTP_LOGIN_MSG', `$j Sendmail $v/$Z; $b; (No UCE/UBE) $?{client_addr}logging access from: ${client_name}(${client_resolve})-$_$.')dnl
dnl #
dnl # Keep dead letter drop, it is the last resort home for abused mail
define(`confDEAD_LETTER_DROP', `/var/lib/sendmail/dead.letter')dnl
dnl #
dnl # Put status file in other than /etc/mail (sendmail default)
dnl # Many people run with R/O /etc
define(`STATUS_FILE', `/var/lib/sendmail/sendmail.st')dnl
define(`confHOST_STATUS_DIRECTORY',
	`/var/lib/sendmail/host_status')dnl
dnl #
dnl # Allow scanf extensions for common text files
define(`confCR_FILE', `-o '`MAIL_SETTINGS_DIR`'relay-domains %[^\#]')dnl
define(`confCT_FILE',      `MAIL_SETTINGS_DIR`'trusted-users %[^\#]')dnl
define(`confCW_FILE',      `MAIL_SETTINGS_DIR`'local-host-names %[^\#]')dnl
dnl #
dnl # This *really* needs a better home
define(`confEBINDIR', `/usr/lib/sm.bin')dnl
dnl #
dnl # add .' to mustquote chars (and match the binary default)
changequote([, ])dnl
define([confMUST_QUOTE_CHARS], [.'])dnl
changequote(`, ')dnl
dnl #
dnl # Default in 8.10+, used to be false (iirc), deprecated
define(`confME_TOO', `True')dnl
dnl #
dnl # Set the default user/group for mailers (mail:mail)
dnl # this should help NIS startup time
dnl #
define(`confDEF_USER_ID', `mail:mail')dnl
dnl #
dnl #---------------------------------------------------------------------
dnl # mailer paths and options
dnl #---------------------------------------------------------------------
define(`LOCAL_MAILER_PATH',  `/usr/sbin/sensible-mda')dnl
define(`LOCAL_MAILER_ARGS',  `sensible-mda $g $u $h ${client_addr}')dnl
MODIFY_MAILER_FLAGS(`LOCAL', `+S')dnl  #do keep root
MODIFY_MAILER_FLAGS(`LOCAL', `-r')dnl  #do not munge args
MODIFY_MAILER_FLAGS(`LOCAL', `-m')dnl  #do not try LMTP
define(`PROCMAIL_MAILER_PATH', `/usr/bin/procmail')dnl
define(`PROCMAIL_MAILER_ARGS', `procmail -m $h $f $u')dnl
define(`USENET_MAILER_PATH', `/usr/bin/inews')dnl
define(`UUCP_MAILER_ARGS',`uux - -r -z -a$g -gC $h!rmail ($u)')dnl
dnl define(`confDEF_CHAR_SET', `iso-8859-1')dnl
dnl #
dnl # Optional items (should be a subset site.config.m4 used for build)
dnl # to prevent sendmail error messages
dnl #
dnl #---------------------------------------------------------------------
dnl # IPv6 support (new option for 8.12+)
dnl # IPv6 causes problems for some DNS servers, work around them
dnl #---------------------------------------------------------------------
ifelse(sm_enable_ipv6, `yes',dnl
`ifelse(eval(sm_version_math >= 527360), `1',dnl
`define(`confBIND_OPTS', `+WorkAroundBrokenAAAA')dnl')')
dnl #
dnl #---------------------------------------------------------------------
dnl # Milter (8.10.0-8.11.0) built-in with 8.12.0+
dnl #---------------------------------------------------------------------
ifelse(sm_enable_milter, `yes',dnl
`define(`_FFR_MILTER')dnl')
#
#-------------------------------------------------------------------------
#
# Undocumented features are available in Debian Sendmail 8.15.2-14~deb10u1.
#	* none
#
# _FFR_ features are available in Debian Sendmail 8.15.2-14~deb10u1.
ifelse(sm_enable_milter, `yes',dnl
`#	* milter')
#	* sm_ffr
#-------------------------------------------------------------------------
#
# These _FFR_ features are for sendmail.mc processing
#
 define(`_FFR_MAIL_MACRO')
#-------------------------------------------------------------------------
