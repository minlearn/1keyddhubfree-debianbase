divert(-1)dnl
#-----------------------------------------------------------------------------
# $Sendmail: starttls.m4,v 8.15.2 2019-08-25 15:04:16 cowboy Exp $
#
# Copyright (c) 2002-2010 Richard Nelson.  All Rights Reserved.
#
# examples/tls/starttls.m4.  Generated from starttls.m4.in by configure.
#
# starttls.m4 m4 file to support user->MTA, MSP->MTA, and MTA->MTA
# encryption and/or authentication.
#
# To use this file, add this line to sendmail.mc and possibly submit.mc:
# `include(`/etc/mail/tls/starttls.m4')dnl'
#
#-----------------------------------------------------------------------------
#
divert(0)dnl
VERSIONID(`$Id: starttls.m4,v 8.15.2-14~deb10u1 2019-08-25 15:04:16 cowboy Exp $')
dnl #
dnl #---------------------------------------------------------------------
dnl # Bring in Autoconf results
dnl #---------------------------------------------------------------------
ifdef(`sm_version', `dnl',
`include(`/usr/share/sendmail/cf/debian/autoconf.m4')dnl')
dnl #
dnl # Check to see if inclusion is valid (version >= 8.11.0, tls enabled)
ifelse(eval(sm_version_math >= 527104), `1', `dnl
ifelse(sm_enable_tls, `yes', `dnl
dnl #
dnl # To support shared keyfiles, we need it to be group readable
dnl #
define(`confDONT_BLAME_SENDMAIL',dnl
    defn(`confDONT_BLAME_SENDMAIL')`,GroupReadableKeyFile')dnl
dnl #
dnl # Set a more reasonable timeout on negotiation
dnl #
define(`confTO_STARTTLS', `2m')dnl      #           , def=10m
dnl #
dnl # Do not touch anything above this line...
dnl #
dnl # CA directory - CA certs should be herein
define(`confCACERT_PATH', `/etc/ssl/certs')dnl
dnl #
dnl # CA file (may be the same as client/server certificate)
define(`confCACERT',      `/etc/mail/tls/sendmail-server.crt')dnl
dnl #
dnl # Server certificate/key (can be in the same file, and shared w/client)
dnl # NOTE: The key must *NOT* be encrypted !!!
define(`confSERVER_CERT', `/etc/mail/tls/sendmail-server.crt')dnl
define(`confSERVER_KEY',  `/etc/mail/tls/sendmail-common.key')dnl
dnl #
dnl # Clien certificate/key (can be in the same file, and shared w/server)
dnl # NOTE: The key must *NOT* be encrypted !!!
define(`confCLIENT_CERT', `/etc/mail/tls/sendmail-client.crt')dnl
define(`confCLIENT_KEY',  `/etc/mail/tls/sendmail-common.key')dnl
dnl #
dnl # DH parameters
define(`confDH_PARAMETERS',`/etc/mail/tls/sendmail-common.prm')dnl
dnl #
dnl # Optional settings
define(`confTLS_SRV_OPTIONS', `')dnl          # do not request user certs
dnl #
dnl # Do not touch anything below this line...
')')dnl
