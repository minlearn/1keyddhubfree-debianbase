divert(-1)dnl
#-----------------------------------------------------------------------------
# $Sendmail: sasl.m4,v 8.15.2 2019-08-25 15:04:16 cowboy Exp $
#
# Copyright (c) 2003-2010 Richard Nelson.  All Rights Reserved.
#
# examples/sasl/sasl.m4.  Generated from sasl.m4.in by configure.
#
# sasl.m4 m4 file to support user->MTA, MSP->MTA, and MTA->MTA
# encryption and/or authentication.
#
# To use this file, add this line to sendmail.mc and possibly submit.mc:
# `include(`/etc/mail/sasl/sasl.m4')dnl'
#
#-----------------------------------------------------------------------------
#
divert(0)dnl
VERSIONID(`$Id: sasl.m4, v 8.15.2-14~deb10u1 2019-08-25 15:04:16 cowboy Exp $')
dnl #
dnl #---------------------------------------------------------------------
dnl # Bring in Autoconf results
dnl #---------------------------------------------------------------------
ifdef(`sm_version', `dnl' ,
`include(`/usr/share/sendmail/cf/debian/autoconf.m4')')dnl
dnl #
dnl #---------------------------------------------------------------------
dnl # SMTP AUTH (SASL) support (sendmail 8.10.0 +)
dnl # PLAIN/LOGIN needed to support SASL auth via PAM ;(
dnl # if this bothers you, you allow them only in conjunction w/STARTTLS !
dnl #---------------------------------------------------------------------
ifelse(eval(sm_version_math >= 526848), `1', `dnl
ifelse(sm_enable_auth, `yes', `dnl
dnl #
dnl # Set a more reasonable timeout on negotiation
dnl #
define(`confTO_AUTH',      `2m')dnl      #           , def=10m
dnl #
dnl # Do not touch anything above this line...
dnl #
dnl # Available Authentication methods
dnl #
define(`confAUTH_MECHANISMS',dnl
`DIGEST-MD5 CRAM-MD5 PLAIN LOGIN')dnl
dnl #
dnl # These, we will trust for relaying
dnl #
TRUST_AUTH_MECH(`DIGEST-MD5 CRAM-MD5 PLAIN LOGIN')
dnl #
dnl # for 8.12.0+, add EXTERNAL as an available & trusted mech (w/STARTTLS)
dnl # and allow sharing of /etc/sasldb(2) file, allow group read/write
dnl #
ifelse(eval(sm_version_math >= 527360), `1', `dnl
define(`confAUTH_MECHANISMS',dnl
`EXTERNAL 'defn(`confAUTH_MECHANISMS'))dnl
TRUST_AUTH_MECH(`EXTERNAL')
define(`confDONT_BLAME_SENDMAIL',dnl
defn(`confDONT_BLAME_SENDMAIL')`,GroupReadableSASLDBFile,GroupWritableSASLDBFile')dnl
')dnl
dnl #
dnl # To support SMTP AUTH in `sendmail -bs' :
dnl # Sigh: SASLV1 MSP AUTH does not work in -bs mode (/etc/sasldb !o+r)
dnl # so, we have the MSP not use Auth (or ETRN)
dnl # SASLV2 (w/saslauth) chose to prohibit user authentication - it can
dnl # be made to work by:
dnl # 1) changing /etc/sasldb2 {root,sasl,smmta}:smmsp 0660
dnl # 2) dpkg-statoverride --remove /var/run/saslauthd
dnl # 3) dpkg-statoverride --add root sasl 711 /var/run/saslauthd
dnl #
ifelse(eval(sm_auth_lib < 2), `1', `dnl
ifdef(`DEBIAN_MSP', `dnl
ifelse(defn(`_DPO_'), `', `dnl
DAEMON_OPTIONS(`Name=NoMTA, Addr=0.0.0.0, M=EA')dnl
')')')dnl
dnl #
dnl # Define the REALM passed to sasl (8.13.0+)
ifelse(eval(sm_version_math >= 527616), `1', `dnl
dnl define(`confAUTH_REALM', `')dnl # Fill this in and uncomment it
')dnl
dnl #
dnl # Do not touch anything below this line...
')')dnl
