package LWP::DebugFile;

our $VERSION = '6.52';

# legacy stub

1;
