/* Architecture-specific additional siginfo constants.  */
#ifndef _BITS_SIGINFO_CONSTS_ARCH_H
#define _BITS_SIGINFO_CONSTS_ARCH_H 1

/* This architecture has no additional siginfo constants.  */

#endif
